//level 1A2A
export default function l1a2b() {
    console.log('This is: Level-1A2A');
}

// Below line causes an error. It has been put here intentionally to demo discovery of bugs from chrome with help of source map.
abcd;
