//level 1B
export default function l1b() {
  console.log('This is: Level-1B');
}
