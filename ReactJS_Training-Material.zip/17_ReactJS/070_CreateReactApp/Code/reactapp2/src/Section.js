import React from "react";

class Section extends React.Component {
  render() {
    return <div>This is a separate section!</div>;
  }
}

export default Section;
