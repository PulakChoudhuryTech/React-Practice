import React from "react";

export default function (props) {
  console.log(props);
  return <h1>About Us Page</h1>;
}
