import React from "react";

export default function () {
  return <h1>Contact Us Page</h1>;
}
