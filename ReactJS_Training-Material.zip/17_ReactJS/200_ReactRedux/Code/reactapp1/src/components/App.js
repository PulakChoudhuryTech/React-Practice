import React from "react";

import Container from "../containers/Container";

class App extends React.Component {
  render() {
    return <Container pageheader="React-Redux Library Demo" />;
  }
}

export default App;
