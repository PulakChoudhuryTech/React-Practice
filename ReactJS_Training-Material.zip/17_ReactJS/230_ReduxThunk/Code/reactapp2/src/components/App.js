import React from 'react';
import UserInfo from '../containers/UserInfo';

function App() {
  return (
    <div>
      <UserInfo />
    </div>
  );
}

export default App;
