import React from "react";
import ReactDOM from "react-dom";
import Foo from "./Foo";

ReactDOM.render(
  <div>
    <Foo />
  </div>,
  document.getElementById("root")
);
