import React from "react";
//import PropTypes from "prop-types";

class Foo extends React.Component {
  render() {
    return <div className="foo">Bar</div>;
  }
}

export default Foo;
