const myBeverage = {
  delicious: true,
  sour: false,
};

module.exports = myBeverage;
